import { Router } from 'express';
import { AnalysisController } from '../controllers/analysis.controller';
import { asyncHandler } from '../middlewares/errorHandler';

const router = Router();
const controller = new AnalysisController();

/**
 * POST /api/analyze
 * Analyze resume vs job description
 */
router.post(
  '/analyze',
  asyncHandler((req, res, next) => controller.analyze(req, res, next))
);

/**
 * GET /api/stats
 * Get cache statistics
 */
router.get(
  '/stats',
  asyncHandler((req, res, next) => controller.getStats(req, res, next))
);

/**
 * POST /api/cleanup
 * Cleanup old analyses (optional maintenance endpoint)
 */
router.post(
  '/cleanup',
  asyncHandler((req, res, next) => controller.cleanup(req, res, next))
);

export default router;
